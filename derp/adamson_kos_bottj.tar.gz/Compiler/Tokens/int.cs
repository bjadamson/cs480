using System;

namespace Tokens
{
	public class Int
	{
		// Properties
		public int Value { get; set; }

		public Int(int val)
		{
			Value = val;
		}
	}

}
