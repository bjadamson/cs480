using System;

namespace Tokens
{
	public class Atom
	{
		// Properties
		public string Value { get; set; }

		public Atom(string val)
		{
			Value = val;
		}
	}

}
