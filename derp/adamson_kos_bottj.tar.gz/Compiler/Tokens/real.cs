using System;

namespace Tokens
{
	public class Real
	{
		// Properties
		public double Value { get; set; }

		public Real(double d)
		{
			Value = d;
		}
	}

}
