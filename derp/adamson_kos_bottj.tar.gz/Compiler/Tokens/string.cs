using System;

namespace Tokens
{
	public class String
	{
		// Properties
		public string Value { get; set; }

		public String(string val)
		{
			Value = val;
		}
	}

}
