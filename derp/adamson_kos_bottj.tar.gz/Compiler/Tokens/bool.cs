using System;

namespace Tokens
{
	public class Bool
	{
		// Properties
		public bool Value { get; set; }

		public Bool(bool b)
		{
			Value = b;
		}
	}

}
